
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Auth"],["c","Question"],["c","Response"],["c","Student"],["c","Teacher"],["c","User"]];
